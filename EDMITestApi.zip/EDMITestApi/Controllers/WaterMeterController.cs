using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using EDMITestApi.Models;
using EDMITestApi.Services;
using EDMITestApi.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace EDMITestApi.Controllers
{
    [ApiController]
    public class WaterMeterController : ControllerBase
    {
        private readonly WaterMeterService service;
        private readonly ILogger<WaterMeterController> logger;
        private readonly IMapper mapper;

        public WaterMeterController(WaterMeterService service,
            IMapper mapper,
            ILogger<WaterMeterController> logger)
        {
            this.service = service;
            this.mapper = mapper;
            this.logger = logger;
        }

        [HttpGet]
        [Route("[controller]")]
        public async Task<IEnumerable<WaterMeterViewModel>> GetAllWaterMeter()
        {
            var ems = await service.GetAllWaterMeters();
            var result = mapper.Map<List<WaterMeterDTO>, IEnumerable<WaterMeterViewModel>>(ems);
            return result;
        }


        [HttpGet]
        [Route("[controller]/GetBySN")]
        public async Task<IActionResult> GetElectricMeterBySN(string sn)
        {
            var foundEm = await service.GetWaterMeterBySN(sn);

            return Ok(foundEm);
        }


        [HttpPost]
        [Route("[controller]/Create")]
        public async Task<IActionResult> CreateWaterMeterRecord([FromBody] WaterMeterDTO newEM)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }
            var isCreated = await service.CreateWaterMeter(newEM);

            if (isCreated == false)
            {
                return BadRequest();
            }
            return Ok();
        }

        [HttpGet]
        [Route("[controller]/Delete")]         
        public async Task<ActionResult> DeleteWaterMeter(string Id)
        {
            var isDeleted = await service.DeleteWaterMeter(Id);
            if(isDeleted == false)
            {
                return BadRequest();
            }
            return Ok();
        }
    }
}

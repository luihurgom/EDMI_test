using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using EDMITestApi.Models;
using EDMITestApi.Services;
using EDMITestApi.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace EDMITestApi.Controllers
{
    [ApiController]
    public class ElectricMeterController : ControllerBase
    {
        private readonly ElectricMeterService service;
        private readonly ILogger<ElectricMeterController> logger;
        private readonly IMapper mapper;

        public ElectricMeterController(ElectricMeterService service,
            IMapper mapper,
            ILogger<ElectricMeterController> logger)
        {
            this.service = service;
            this.mapper = mapper;
            this.logger = logger;
        }

        [HttpGet]
        [Route("[controller]")]
        public async Task<IEnumerable<ElectricMeterViewModel>> GetAllElectricMeter()
        {
            var ems = await service.GetAllElectricMeters();
            var result = mapper.Map<List<ElectricMeterDTO>, IEnumerable<ElectricMeterViewModel>>(ems);
            return result;
        }

        [HttpGet]
        [Route("[controller]/GetBySN")]
        public async Task<IActionResult> GetElectricMeterBySN(string sn)
        {
            var foundEm = await service.GetElectricMeterBySN(sn);

            return Ok(foundEm);
        }

        [HttpPost]
        [Route("[controller]/Create")]
        public async Task<IActionResult> CreateElectricMeterRecord([FromBody] ElectricMeterDTO newEm)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }
            var isCreated = await service.CreateElectricMeter(newEm);

            if (isCreated == false)
            {
                return BadRequest();
            }
            return Ok();
        }

        [HttpGet]
        [Route("[controller]/Delete")]        
        public async Task<ActionResult> DeleteElectricMeter(string Id)
        {
            var isDeleted = await service.DeleteElectricMeter(Id);
            if(isDeleted == false)
            {
                return BadRequest();
            }
            return Ok();
        }
    }
}

﻿using System;
namespace EDMITestApi.Models
{
    public class DbSettings : IDbSettings
    {
        
        public string ConnectionString { get; set; }
        public string DatabaseName { get; set; }
        public string ElectricMeterCollectionName { get; set; }
        public string WaterMeterCollectionName { get; set; }
        public string GatewayCollectionName { get; set; }
    }
}

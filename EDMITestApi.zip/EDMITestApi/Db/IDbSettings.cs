﻿namespace EDMITestApi.Models
{
    public interface IDbSettings
    {
        string ElectricMeterCollectionName { get; set; }
        string WaterMeterCollectionName { get; set; }
        string GatewayCollectionName { get; set; }
        string ConnectionString { get; set; }
        string DatabaseName { get; set; }
    }
}

using System;
using AutoMapper;
using EDMITestApi.Models;
using EDMITestApi.ViewModels;

namespace EDMITestApi.AutoMappers
{
    public class ElectricMeterProfile : Profile
    {
        public ElectricMeterProfile()
        {
            CreateMap<ElectricMeterDTO, ElectricMeterViewModel>();
        }
    }
}

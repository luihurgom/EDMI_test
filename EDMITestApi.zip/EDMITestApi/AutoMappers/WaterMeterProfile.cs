using System;
using AutoMapper;
using EDMITestApi.Models;
using EDMITestApi.ViewModels;

namespace EDMITestApi.AutoMappers
{
    public class WaterMeterProfile : Profile
    {
        public WaterMeterProfile()
        {
            CreateMap<WaterMeterDTO, WaterMeterViewModel>();
        }
    }
}

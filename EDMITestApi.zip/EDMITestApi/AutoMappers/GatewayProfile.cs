using System;
using AutoMapper;
using EDMITestApi.Models;
using EDMITestApi.ViewModels;

namespace EDMITestApi.AutoMappers
{
    public class GatewayProfile : Profile
    {
        public GatewayProfile()
        {
            CreateMap<GatewayDTO, GatewayViewModel>();
        }
    }
}

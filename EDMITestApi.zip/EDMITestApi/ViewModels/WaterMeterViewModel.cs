using System;
using EDMITestApi.Models;

namespace EDMITestApi.ViewModels
{
    public class WaterMeterViewModel
    {
        public string Id { get; set; }
        public string SerialNumber { get; set; }
        public string FirmwareVersion { get; set; }
        public string State { get; set; }
    }
}

using System;
using EDMITestApi.Models;

namespace EDMITestApi.ViewModels
{
    public class GatewayViewModel
    {
        public string Id { get; set; }
        public string SerialNumber { get; set; }
        public string FirmwareVersion { get; set; }
        public string State { get; set; }
        public string IP { get; set; }
        public string Port { get; set; }
        public string Description { get; set; }

    }
}

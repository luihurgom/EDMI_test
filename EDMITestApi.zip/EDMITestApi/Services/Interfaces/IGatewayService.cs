using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DnsClient.Internal;
using EDMITestApi.Models;
using Microsoft.Extensions.Logging;
using MongoDB.Bson;
using MongoDB.Driver;

namespace EDMITestApi.Services
{
    public interface IGatewayService
    {
        Task<List<GatewayDTO>> GetAllGateways();

        Task<bool> CreateGateway(GatewayDTO newGateway);

        Task<bool> GetGatewayBySN(string sn);

        Task<bool> DeleteGateway(string id);

    }
}

using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DnsClient.Internal;
using EDMITestApi.Models;
using Microsoft.Extensions.Logging;
using MongoDB.Bson;
using MongoDB.Driver;

namespace EDMITestApi.Services
{
    public interface IElectricMeterService
    {
        Task<List<ElectricMeterDTO>> GetAllElectricMeters();

        Task<bool> CreateElectricMeter(ElectricMeterDTO newElectricMeter);

        Task<bool> GetElectricMeterBySN(string sn);

        Task<bool> DeleteElectricMeter(string id);       

    }
}

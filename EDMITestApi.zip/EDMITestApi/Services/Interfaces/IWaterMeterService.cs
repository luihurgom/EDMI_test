using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DnsClient.Internal;
using EDMITestApi.Models;
using Microsoft.Extensions.Logging;
using MongoDB.Bson;
using MongoDB.Driver;

namespace EDMITestApi.Services
{
    public interface IWaterMeterService
    {
        Task<List<WaterMeterDTO>> GetAllWaterMeters();

        Task<bool> CreateWaterMeter(WaterMeterDTO newWaterMeter);

        Task<bool> GetWaterMeterBySN(string sn);

        Task<bool> DeleteWaterMeter(string id);

    }
}

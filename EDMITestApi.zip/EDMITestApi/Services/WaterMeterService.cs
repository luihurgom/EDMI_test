using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DnsClient.Internal;
using EDMITestApi.Models;
using Microsoft.Extensions.Logging;
using MongoDB.Bson;
using MongoDB.Driver;

namespace EDMITestApi.Services
{
    public class WaterMeterService : IWaterMeterService
    {
        private readonly IMongoCollection<WaterMeterDTO> watMeters;
        private readonly ILogger<WaterMeterService> logger;

        public WaterMeterService(IDbSettings dbSettings,
            ILogger<WaterMeterService> logger)
        {
            this.logger = logger;
            var client = new MongoClient(dbSettings.ConnectionString);
            var db = client.GetDatabase(dbSettings.DatabaseName);
            watMeters = db.GetCollection<WaterMeterDTO>(dbSettings.WaterMeterCollectionName);
        }


        public async Task<List<WaterMeterDTO>> GetAllWaterMeters()
        {
            List<WaterMeterDTO> allWms = null;
            try
            {
                var result = watMeters.Find(x => true).Sort("{Id: 1}");
                allWms = result.ToList();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Get all wm failed.");
            }
            return allWms;
        }

        public async Task<bool> CreateWaterMeter(WaterMeterDTO newWaterMeter)
        {
            var isCreated = false;
            try
            {
                await watMeters.InsertOneAsync(newWaterMeter);
                isCreated = true;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Create WaterMeter record failed.");
            }
            return isCreated;
        }

        public async Task<bool> GetWaterMeterBySN(string sn)
        {
            bool foundEM = false;
            try
            {
                var result = await watMeters.FindAsync(wm => sn.Equals(wm.SerialNumber));
                foundEM = result.Any();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Get ElectricMeter by ID failed.");
            }
            return foundEM;
        }


        public async Task<bool> DeleteWaterMeter(string id)
        {
            var isDeleted = false;
            try
            {
                await watMeters.DeleteOneAsync(wm => ObjectId.Parse(id).Equals(wm.Id));
                isDeleted = true;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Delete wm failed.");
            }
            return isDeleted;
        }

    }
}

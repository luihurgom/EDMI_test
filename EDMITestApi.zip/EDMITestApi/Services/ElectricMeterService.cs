using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DnsClient.Internal;
using EDMITestApi.Models;
using Microsoft.Extensions.Logging;
using MongoDB.Bson;
using MongoDB.Driver;

namespace EDMITestApi.Services
{
    public class ElectricMeterService : IElectricMeterService
    {
        private readonly IMongoCollection<ElectricMeterDTO> elMeters;
        private readonly ILogger<ElectricMeterService> logger;

        public ElectricMeterService(IDbSettings dbSettings,
            ILogger<ElectricMeterService> logger)
        {
            this.logger = logger;
            var client = new MongoClient(dbSettings.ConnectionString);
            var db = client.GetDatabase(dbSettings.DatabaseName);
            elMeters = db.GetCollection<ElectricMeterDTO>(dbSettings.ElectricMeterCollectionName);
        }

        public async Task<List<ElectricMeterDTO>> GetAllElectricMeters()
        {
            List<ElectricMeterDTO> allEms = null;
            try
            {
                var result = elMeters.Find(x => true).Sort("{Id: 1}");
                allEms = result.ToList();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Get all em failed.");
            }
            return allEms;
        }

        public async Task<bool> CreateElectricMeter(ElectricMeterDTO newElectricMeter)
        {
            var isCreated = false;
            try
            {
                await elMeters.InsertOneAsync(newElectricMeter);
                isCreated = true;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Create ElectricMeter record failed.");
            }
            return isCreated;
        }

        public async Task<bool> GetElectricMeterBySN(string sn)
        {
            bool foundEM = false;
            try
            {
                var result = await elMeters.FindAsync(em => sn.Equals(em.SerialNumber));
                foundEM = result.Any();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Get ElectricMeter by ID failed.");
            }
            return foundEM;
        }

        public async Task<bool> DeleteElectricMeter(string id)
        {
            var isDeleted = false;
            try
            {
                await elMeters.DeleteOneAsync(em => ObjectId.Parse(id).Equals(em.Id));
                isDeleted = true;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Delete EM failed.");
            }
            return isDeleted;
        }

    }
}

using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DnsClient.Internal;
using EDMITestApi.Models;
using Microsoft.Extensions.Logging;
using MongoDB.Bson;
using MongoDB.Driver;

namespace EDMITestApi.Services
{
    public class GatewayService : IGatewayService
    {
        private readonly IMongoCollection<GatewayDTO> gts;
        private readonly ILogger<GatewayService> logger;

        public GatewayService(IDbSettings dbSettings,
            ILogger<GatewayService> logger)
        {
            this.logger = logger;
            var client = new MongoClient(dbSettings.ConnectionString);
            var db = client.GetDatabase(dbSettings.DatabaseName);
            gts = db.GetCollection<GatewayDTO>(dbSettings.GatewayCollectionName);
        }

        public async Task<List<GatewayDTO>> GetAllGateways()
        {
            List<GatewayDTO> allGts = null;
            try
            {
                var result = gts.Find(x => true).Sort("{Id: 1}");
                allGts = result.ToList();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Get all gateways failed.");
            }
            return allGts;
        }

        public async Task<bool> CreateGateway(GatewayDTO newGateway)
        {
            var isCreated = false;
            try
            {
                await gts.InsertOneAsync(newGateway);
                isCreated = true;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Create Gateway record failed.");
            }
            return isCreated;
        }

        public async Task<bool> GetGatewayBySN(string sn)
        {
            bool foundG = false;
            try
            {
                var result = await gts.FindAsync(gt => sn.Equals(gt.SerialNumber));
                foundG = result.Any();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Get Gateway by ID failed.");
            }
            return foundG;
        }


        public async Task<bool> DeleteGateway(string id)
        {
            var isDeleted = false;
            try
            {
                await gts.DeleteOneAsync(g => ObjectId.Parse(id).Equals(g.Id));
                isDeleted = true;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Delete G failed.");
            }
            return isDeleted;
        }

    }
}

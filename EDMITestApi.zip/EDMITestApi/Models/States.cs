﻿using System;
namespace EDMITestApi.Models
{
    public enum States
    {
        Open,
        Closed
    }
}

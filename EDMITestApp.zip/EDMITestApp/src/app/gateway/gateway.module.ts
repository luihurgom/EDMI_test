import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GatewayComponent } from './gateway.component';
import { Routes, RouterModule } from '@angular/router';
import { SharedMatModule } from '../shared/shared-mat.module';
import { GtRoutingModule } from './gateway.routing';

@NgModule({
    declarations: [GatewayComponent],
    imports: [
        CommonModule,
        SharedMatModule,
        RouterModule,
        GtRoutingModule,
    ]
})
export class GatewayModule { }

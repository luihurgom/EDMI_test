import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GatewayComponent } from './gateway.component';

const routes: Routes = [
    {
        path: '',
        component: GatewayComponent
    },

    {
        path: 'new-gt',
        loadChildren: () => import('./new-gt/new-gt.module').then(m => m.NewGtModule)
    }
];
@NgModule({
    imports: [
        RouterModule.forChild(routes)
    ]
})
export class GtRoutingModule { }

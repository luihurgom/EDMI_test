import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../../data.service';
import { GtModel } from '../../models/gateway.model';
import { States } from '../../models/states.enum';

@Component({
    selector: 'app-new-gt',
    templateUrl: './new-gt.component.html',
    styleUrls: ['./new-gt.component.css']
})
export class NewGtComponent implements OnInit {
    newGt: GtModel = new GtModel();
    Id: string;
    SN: string;
    stateOptions = [];

    constructor(
        private dataService: DataService,
        private router: Router,
        private activatedRoute: ActivatedRoute) { }

    ngOnInit(): void {
        this.Id = this.activatedRoute.snapshot.paramMap.get('Id');
        console.log(this.Id);

        this.stateOptions = Object.keys(States).filter(
            (type) => isNaN(type as any) && type !== 'values'
        );
        console.log(this.stateOptions);

    }

    checkSN(SN: string){
        console.log(SN);
        this.dataService.checkSN_Gt(SN).subscribe(response => {
            console.log(response);
        });
    }

    createGt() {
        console.log(this.newGt.SerialNumber);
       
        this.dataService.checkSN_Gt(this.newGt.SerialNumber).subscribe(response => {
            if(!response){
                this.dataService.createNewGt(this.newGt).subscribe(response => {
                    console.log(response);
                    this.router.navigateByUrl('/gateway');
                });
            }else{
                alert('This SN is already registered');
            }
        });
        

    }

}

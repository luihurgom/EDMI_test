import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { SharedMatModule } from '../../shared/shared-mat.module';
import { NewGtComponent } from './new-gt.component';


const routes: Routes = [
  { path: '', component: NewGtComponent }
];

@NgModule({
  declarations: [NewGtComponent],
  imports: [
    CommonModule,
    SharedMatModule,
    RouterModule.forChild(routes)
  ]
})
export class NewGtModule { }

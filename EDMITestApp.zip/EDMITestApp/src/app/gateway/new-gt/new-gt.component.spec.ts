import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewGtComponent } from './new-gt.component';

import { Component, OnInit, AfterContentInit, AfterViewInit, ViewChild } from '@angular/core';
import { DataService } from '../data.service';
import { GtModel } from '../models/gateway.model';
import { Router } from '@angular/router';

@Component({
    selector: 'app-gateway',
    templateUrl: './gateway.component.html',
    styleUrls: ['./gateway.component.css']
})
export class GatewayComponent implements OnInit {

    allGt: Array<GtModel> = [];
    selectedGt: GtModel;
    selectedGtId: string;
    displayedColumns = ['select','SerialNumber','FirmwareVersion','State','IP','Port','Description'];
    priorityOptions = [];
    constructor(
        private dataService: DataService,
        private router: Router) { }

    ngOnInit(): void {
        console.log('GT initialized...');
        

        this.dataService.getAllGt().subscribe(gat => {
            console.log(gat);
            this.allGt = gat;
            if (this.allGt && this.allGt.length > 0) {
                this.selectedGt = this.allGt[0];
                this.onGtSelected(this.selectedGt);
            }
        });
    }

    onGtSelected(gat: GtModel) {
        console.log('seleccionado!');
        console.log(gat);
        this.selectedGtId = gat.Id;
        this.selectedGt = gat;
    }

    onNewGt() {
        this.router.navigate(['/gateway/new-gt/']);
    }

    deleteGt() {
        console.log(this.selectedGtId);
        if (window.confirm('Are you sure to delete this gateway?')) {
            this.dataService.deleteGt(this.selectedGtId).subscribe(response => {
                this.ngOnInit();
            });
        }
    }
    
    onGtSelection(Id: string) {
        console.log('seleccionado!');
        this.selectedGtId = Id; 
        console.log(Id);
    }
}

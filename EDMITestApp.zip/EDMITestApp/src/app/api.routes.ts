import { environment } from '../environments/environment';

export const ApiRoutes = {
    DeleteElectricMeter:  environment.apiUrl + `ElectricMeter/Delete?Id={Id}`,
    GetElectricMeterBySN: environment.apiUrl + `ElectricMeter/GetBySN?sn={Sn}`,
    CreateElectricMeter:  environment.apiUrl + `ElectricMeter/Create`,
    GetAllElectricMeter:  environment.apiUrl + `ElectricMeter`,

    DeleteWaterMeter:  environment.apiUrl + `WaterMeter/Delete?Id={Id}`,
    GetWaterMeterBySN: environment.apiUrl + `WaterMeter/GetBySN?sn={Sn}`,
    CreateWaterMeter:  environment.apiUrl + `WaterMeter/Create`,
    GetAllWaterMeter:  environment.apiUrl + `WaterMeter`,
    
    DeleteGateway:  environment.apiUrl + `Gateway/Delete?Id={Id}`,
    GetGatewayBySN: environment.apiUrl + `Gateway/GetBySN?sn={Sn}`,
    CreateGateway:  environment.apiUrl + `Gateway/Create`,
    GetAllGateway:  environment.apiUrl + `Gateway`,


};

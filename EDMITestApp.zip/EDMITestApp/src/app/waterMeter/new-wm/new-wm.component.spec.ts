import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewWMComponent } from './new-wm.component';

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../../data.service';
import { WMModel } from '../../models/watermeter.model';
import { States } from '../../models/states.enum';

@Component({
    selector: 'app-new-em',
    templateUrl: './new-wm.component.html',
    styleUrls: ['./new-wm.component.css']
})
export class NewWMComponent implements OnInit {
    newWM: WMModel = new WMModel();
    Id: string;
    SN: string;
    stateOptions = [];

    constructor(
        private dataService: DataService,
        private router: Router,
        private activatedRoute: ActivatedRoute) { }

    ngOnInit(): void {
        this.Id = this.activatedRoute.snapshot.paramMap.get('Id');
        console.log(this.Id);

        this.stateOptions = Object.keys(States).filter(
            (type) => isNaN(type as any) && type !== 'values'
        );
        console.log(this.stateOptions);

    }

    checkSN(SN: string){
        console.log(SN);
        this.dataService.checkSN_WM(SN).subscribe(response => {
            console.log(response);
        });
    }

    createWM() {
        console.log(this.newWM.SerialNumber);
       
        this.dataService.checkSN_WM(this.newWM.SerialNumber).subscribe(response => {
            if(!response){
                this.dataService.createNewWM(this.newWM).subscribe(response => {
                    console.log(response);
                    this.router.navigateByUrl('/watermeter');
                });
            }else{
                alert('This SN is already registered');
            }
        });
        

    }

}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { SharedMatModule } from '../../shared/shared-mat.module';
import { NewWMComponent } from './new-wm.component';


const routes: Routes = [
  { path: '', component: NewWMComponent }
];

@NgModule({
  declarations: [NewWMComponent],
  imports: [
    CommonModule,
    SharedMatModule,
    RouterModule.forChild(routes)
  ]
})
export class NewWMModule { }

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WaterMeterComponent } from './waterMeter.component';
import { Routes, RouterModule } from '@angular/router';
import { SharedMatModule } from '../shared/shared-mat.module';
import { WMRoutingModule } from './waterMeter.routing';

@NgModule({
    declarations: [WaterMeterComponent],
    imports: [
        CommonModule,
        SharedMatModule,
        RouterModule,
        WMRoutingModule,
    ]
})
export class WaterMeterModule { }

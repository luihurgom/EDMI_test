import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WaterMeterComponent } from './waterMeter.component';

const routes: Routes = [
    {
        path: '',
        component: WaterMeterComponent
    },

    {
        path: 'new-wm',
        loadChildren: () => import('./new-wm/new-wm.module').then(m => m.NewWMModule)
    }
];
@NgModule({
    imports: [
        RouterModule.forChild(routes)
    ]
})
export class WMRoutingModule { }

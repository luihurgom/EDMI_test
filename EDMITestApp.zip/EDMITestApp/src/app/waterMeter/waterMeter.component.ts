import { Component, OnInit, AfterContentInit, AfterViewInit, ViewChild } from '@angular/core';
import { DataService } from '../data.service';
import { WMModel } from '../models/watermeter.model';
import { Router } from '@angular/router';

@Component({
    selector: 'app-waterMeter',
    templateUrl: './waterMeter.component.html',
    styleUrls: ['./waterMeter.component.css']
})
export class WaterMeterComponent implements OnInit {

    allWM: Array<WMModel> = [];
    selectedWM: WMModel;
    selectedWMId: string;
    displayedColumns = ['select','SerialNumber','FirmwareVersion','State'];
    priorityOptions = [];
    constructor(
        private dataService: DataService,
        private router: Router) { }

    ngOnInit(): void {
        console.log('WM initialized...');
        

        this.dataService.getAllWM().subscribe(em => {
            console.log(em);
            this.allWM = em;
            if (this.allWM && this.allWM.length > 0) {
                this.selectedWM = this.allWM[0];
                this.onEMSelected(this.selectedWM);
            }
        });
    }

    onEMSelected(wm: WMModel) {
        console.log('seleccionado!');
        console.log(wm);
        this.selectedWMId = wm.Id;
        this.selectedWM = wm;
    }

    onNewWM() {
        this.router.navigate(['/watermeter/new-wm/']);
    }

    deleteWM() {
        console.log(this.selectedWMId);
        if (window.confirm('Are you sure to delete this WM?')) {
            this.dataService.deleteWM(this.selectedWMId).subscribe(response => {
                this.ngOnInit();
            });
        }
    }

    onWMSelection(Id: string) {
        console.log('seleccionado!');
        this.selectedWMId = Id;
        console.log(Id);
    }
}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
    {
        path: 'electricmeter',
        loadChildren: () => import('./electricMeter/electricMeter.module').then(m => m.ElectricMeterModule)
    },
    {
        path: '',
        redirectTo: '/electricmeter',
        pathMatch: 'full'
    },
    { path: 'watermeter', loadChildren: () => import('./waterMeter/waterMeter.module').then(m => m.WaterMeterModule) },
    { path: 'gateway', loadChildren: () => import('./gateway/gateway.module').then(m => m.GatewayModule) }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }

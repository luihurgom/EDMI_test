import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiRoutes } from './api.routes';
import { Observable } from 'rxjs';
import { EMModel } from './models/electricmeter.model';
import { WMModel } from './models/watermeter.model';
import { GtModel } from './models/gateway.model';

@Injectable({
    providedIn: 'root'
})
export class DataService {

    constructor(private httpClient: HttpClient) { }

    getAllEM(): Observable<Array<EMModel>> {
        return this.httpClient.get<Array<EMModel>>(ApiRoutes.GetAllElectricMeter);
    }

    createNewEM(newEM: EMModel) {
        return this.httpClient.post(ApiRoutes.CreateElectricMeter, newEM);
    }
    checkSN_EM(SN: string){        
        return this.httpClient.get(ApiRoutes.GetElectricMeterBySN.replace(`{Sn}`, SN));
    }

    deleteEM(Id: string){
        console.log(Id);
        return this.httpClient.get(ApiRoutes.DeleteElectricMeter.replace(`{Id}`, Id));
    }


    getAllWM(): Observable<Array<WMModel>> {
        return this.httpClient.get<Array<WMModel>>(ApiRoutes.GetAllWaterMeter);
    }

    createNewWM(newEM: WMModel) {
        return this.httpClient.post(ApiRoutes.CreateWaterMeter, newEM);
    }
    checkSN_WM(SN: string){        
        return this.httpClient.get(ApiRoutes.GetWaterMeterBySN.replace(`{Sn}`, SN));
    }

    deleteWM(Id: string){
        console.log(Id);
        return this.httpClient.get(ApiRoutes.DeleteWaterMeter.replace(`{Id}`, Id));
    }
  

    getAllGt(): Observable<Array<GtModel>> {
        return this.httpClient.get<Array<GtModel>>(ApiRoutes.GetAllGateway);
    }

    createNewGt(newGt: GtModel) {
        return this.httpClient.post(ApiRoutes.CreateGateway, newGt);
    }
    checkSN_Gt(SN: string){        
        return this.httpClient.get(ApiRoutes.GetGatewayBySN.replace(`{Sn}`, SN));
    }

    deleteGt(Id: string){
        console.log(Id);
        return this.httpClient.get(ApiRoutes.DeleteGateway.replace(`{Id}`, Id));
    }

}

import { States } from './states.enum';

export class GtModel {
    Id: string;
    SerialNumber: string;
    FirmwareVersion: string;
    State: States;
    IP: string;
    Port: string;
    Description: string;
}

import { States } from './states.enum';

export class EMModel {
    Id: string;
    SerialNumber: string;
    FirmwareVersion: string;
    State: States;
}

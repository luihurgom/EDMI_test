export enum States {
    Open,
    Closed
}

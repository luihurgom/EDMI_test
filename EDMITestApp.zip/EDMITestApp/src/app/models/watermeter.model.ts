import { States } from './states.enum';

export class WMModel {
    Id: string;
    SerialNumber: string;
    FirmwareVersion: string;
    State: States;
}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../../data.service';
import { EMModel } from '../../models/electricmeter.model';
import { States } from '../../models/states.enum';

@Component({
    selector: 'app-new-em',
    templateUrl: './new-em.component.html',
    styleUrls: ['./new-em.component.css']
})
export class NewEMComponent implements OnInit {
    newEM: EMModel = new EMModel();
    Id: string;
    SN: string;
    stateOptions = [];

    constructor(
        private dataService: DataService,
        private router: Router,
        private activatedRoute: ActivatedRoute) { }

    ngOnInit(): void {
        this.Id = this.activatedRoute.snapshot.paramMap.get('Id');
        console.log(this.Id);

        this.stateOptions = Object.keys(States).filter(
            (type) => isNaN(type as any) && type !== 'values'
        );
        console.log(this.stateOptions);

    }

    checkSN(SN: string){
        console.log(SN);
        this.dataService.checkSN_EM(SN).subscribe(response => {
            console.log(response);
        });
    }

    createEM() {
        console.log(this.newEM.SerialNumber);
       
        this.dataService.checkSN_EM(this.newEM.SerialNumber).subscribe(response => {
            if(!response){
                this.dataService.createNewEM(this.newEM).subscribe(response => {
                    console.log(response);
                    this.router.navigateByUrl('/electricmeter');
                });
            }else{
                alert('This SN is already registered');
            }
        });
        

    }

}

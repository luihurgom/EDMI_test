import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { SharedMatModule } from '../../shared/shared-mat.module';
import { NewEMComponent } from './new-em.component';


const routes: Routes = [
  { path: '', component: NewEMComponent }
];

@NgModule({
  declarations: [NewEMComponent],
  imports: [
    CommonModule,
    SharedMatModule,
    RouterModule.forChild(routes)
  ]
})
export class NewEMModule { }

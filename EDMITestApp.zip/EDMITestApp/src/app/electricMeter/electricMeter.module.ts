import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ElectricMeterComponent } from './electricMeter.component';
import { Routes, RouterModule } from '@angular/router';
import { SharedMatModule } from '../shared/shared-mat.module';
import { EMRoutingModule } from './electricMeter.routing';

@NgModule({
    declarations: [ElectricMeterComponent],
    imports: [
        CommonModule,
        SharedMatModule,
        RouterModule,
        EMRoutingModule,
    ]
})
export class ElectricMeterModule { }

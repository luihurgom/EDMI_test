import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ElectricMeterComponent } from './electricMeter.component';

describe('ElectricMeterComponent', () => {
  let component: ElectricMeterComponent;
  let fixture: ComponentFixture<ElectricMeterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ElectricMeterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ElectricMeterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit, AfterContentInit, AfterViewInit, ViewChild } from '@angular/core';
import { DataService } from '../data.service';
import { EMModel } from '../models/electricmeter.model';
import { Router } from '@angular/router';

@Component({
    selector: 'app-electricMeter',
    templateUrl: './electricMeter.component.html',
    styleUrls: ['./electricMeter.component.css']
})
export class ElectricMeterComponent implements OnInit {

    allEM: Array<EMModel> = [];
    selectedEM: EMModel;
    selectedEMId: string;
    displayedColumns = ['select','SerialNumber','FirmwareVersion','State'];
    priorityOptions = [];
    constructor(
        private dataService: DataService,
        private router: Router) { }

    ngOnInit(): void {
        console.log('EM initialized...');
        

        this.dataService.getAllEM().subscribe(em => {
            console.log(em);
            this.allEM = em;
            if (this.allEM && this.allEM.length > 0) {
                this.selectedEM = this.allEM[0];
                this.onEMSelected(this.selectedEM);
            }
        });
    }

    onEMSelected(em: EMModel) {
        console.log('seleccionado!');
        console.log(em);
        this.selectedEMId = em.Id;
        this.selectedEM = em;
    }

    onNewEM() {
        this.router.navigate(['/electricmeter/new-em/']);
    }

    deleteEM() {
        console.log(this.selectedEMId);
        if (window.confirm('Are you sure to delete this EM?')) {
            this.dataService.deleteEM(this.selectedEMId).subscribe(response => {
                this.ngOnInit();
            });
        }
    }

    onEMSelection(Id: string) {
        console.log('seleccionado!');
        this.selectedEMId = Id;
        console.log(Id);
    }
}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ElectricMeterComponent } from './electricMeter.component';

const routes: Routes = [
    {
        path: '',
        component: ElectricMeterComponent
    },

    {
        path: 'new-em',
        loadChildren: () => import('./new-em/new-em.module').then(m => m.NewEMModule)
    }
];
@NgModule({
    imports: [
        RouterModule.forChild(routes)
    ]
})
export class EMRoutingModule { }
